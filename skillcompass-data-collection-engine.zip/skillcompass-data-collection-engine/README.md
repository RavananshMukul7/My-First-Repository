# SkillCompass — Data Collection Engine

Source-code-first GitHub collection for the SkillCompass MVP.

## Flow

GitHub user token → public owned repositories → recursive repository tree → source-code filtering → repository-wise local folders → Skill Extraction Engine

## Usage

```js
const { collectUserRepositories } = require('./src/githubDataCollector');

const result = await collectUserRepositories({
  token: process.env.GITHUB_TOKEN,
  outputRoot: './collected-repositories'
});

console.log(result);
```

The collector intentionally does not use README, package manifests, lockfiles, or dependency declarations as skill evidence.
