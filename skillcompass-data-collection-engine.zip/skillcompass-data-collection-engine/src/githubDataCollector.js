const fs = require('node:fs/promises');
const path = require('node:path');

const GITHUB_API = 'https://api.github.com';
const GITHUB_API_VERSION = '2026-03-10';

const SOURCE_EXTENSIONS = new Set([
  '.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs',
  '.py', '.java', '.c', '.h', '.cpp', '.cc', '.cxx', '.hpp',
  '.cs', '.go', '.rs', '.rb', '.php', '.swift', '.kt', '.kts',
  '.scala', '.sh', '.bash', '.zsh', '.fish', '.sql',
  '.html', '.css', '.scss', '.sass', '.less',
  '.vue', '.svelte'
]);

const IGNORED_DIRS = new Set([
  '.git', 'node_modules', 'vendor', 'dist', 'build', 'coverage',
  '.next', '.nuxt', '.cache', '.pytest_cache', '__pycache__',
  '.venv', 'venv', 'env', 'target', 'bin', 'obj'
]);

const MAX_FILE_BYTES = 200 * 1024; // Keep collected files manageable for LLM analysis.

function isSourceFile(filePath) {
  const normalized = filePath.replaceAll('\\', '/');
  const segments = normalized.split('/');
  if (segments.some((segment) => IGNORED_DIRS.has(segment))) return false;

  const ext = path.extname(normalized).toLowerCase();
  return SOURCE_EXTENSIONS.has(ext);
}

async function githubRequest(endpoint, token) {
  const response = await fetch(`${GITHUB_API}${endpoint}`, {
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: `Bearer ${token}`,
      'X-GitHub-Api-Version': GITHUB_API_VERSION,
      'User-Agent': 'SkillCompass/1.0'
    }
  });

  if (!response.ok) {
    const body = await response.text();
    const error = new Error(`GitHub API ${response.status}: ${body}`);
    error.status = response.status;
    throw error;
  }

  return response.json();
}

async function listPublicRepositories(token) {
  const repositories = [];
  let page = 1;

  while (true) {
    const batch = await githubRequest(
      `/user/repos?visibility=public&affiliation=owner&per_page=100&page=${page}&sort=pushed`,
      token
    );

    repositories.push(...batch);
    if (batch.length < 100) break;
    page += 1;
  }

  return repositories;
}

async function getRepositoryTree(owner, repo, branch, token) {
  const encodedBranch = encodeURIComponent(branch);
  const tree = await githubRequest(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/trees/${encodedBranch}?recursive=1`,
    token
  );

  return tree.tree.filter((entry) => entry.type === 'blob');
}

async function getRawFile(owner, repo, filePath, token) {
  const endpoint =
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${filePath
      .split('/')
      .map(encodeURIComponent)
      .join('/')}`;

  const response = await fetch(`${GITHUB_API}${endpoint}`, {
    headers: {
      Accept: 'application/vnd.github.raw+json',
      Authorization: `Bearer ${token}`,
      'X-GitHub-Api-Version': GITHUB_API_VERSION,
      'User-Agent': 'SkillCompass/1.0'
    }
  });

  if (!response.ok) {
    const body = await response.text();
    const error = new Error(`GitHub API ${response.status}: ${body}`);
    error.status = response.status;
    throw error;
  }

  return Buffer.from(await response.arrayBuffer());
}

async function collectRepository(repository, token, outputRoot) {
  const owner = repository.owner.login;
  const repoName = repository.name;
  const branch = repository.default_branch;

  const tree = await getRepositoryTree(owner, repoName, branch, token);
  const candidates = tree.filter(
    (entry) => isSourceFile(entry.path) && Number(entry.size || 0) <= MAX_FILE_BYTES
  );

  const repoOutputDir = path.join(outputRoot, repoName);
  await fs.mkdir(repoOutputDir, { recursive: true });

  const collectedFiles = [];
  const skippedFiles = [];

  for (const entry of candidates) {
    try {
      const content = await getRawFile(owner, repoName, entry.path, token);
      const relativePath = entry.path.replaceAll('\\', '/');
      const target = path.join(repoOutputDir, relativePath);

      await fs.mkdir(path.dirname(target), { recursive: true });
      await fs.writeFile(target, content);

      collectedFiles.push({
        path: relativePath,
        bytes: content.length,
        sha: entry.sha
      });
    } catch (error) {
      skippedFiles.push({ path: entry.path, reason: error.message });
    }
  }

  const manifest = {
    repository: repoName,
    owner,
    defaultBranch: branch,
    collectedAt: new Date().toISOString(),
    fileCount: collectedFiles.length,
    skippedCount: skippedFiles.length,
    files: collectedFiles,
    skippedFiles
  };

  await fs.writeFile(
    path.join(repoOutputDir, '_collection-manifest.json'),
    JSON.stringify(manifest, null, 2)
  );

  return manifest;
}

async function collectUserRepositories({ token, outputRoot = './collected-repositories' }) {
  if (!token) throw new Error('GitHub token is required.');

  await fs.mkdir(outputRoot, { recursive: true });
  const repositories = await listPublicRepositories(token);
  const manifests = [];

  for (const repository of repositories) {
    if (repository.fork || repository.archived || repository.disabled) continue;

    const manifest = await collectRepository(repository, token, outputRoot);
    manifests.push(manifest);
  }

  const summary = {
    collectedAt: new Date().toISOString(),
    repositoryCount: manifests.length,
    repositories: manifests
  };

  await fs.writeFile(
    path.join(outputRoot, '_collection-summary.json'),
    JSON.stringify(summary, null, 2)
  );

  return summary;
}

module.exports = {
  collectUserRepositories,
  listPublicRepositories,
  getRepositoryTree,
  isSourceFile
};
