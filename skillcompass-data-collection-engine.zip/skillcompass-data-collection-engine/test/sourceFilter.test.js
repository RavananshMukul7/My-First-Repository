const assert = require('node:assert/strict');
const { isSourceFile } = require('../src/githubDataCollector');

assert.equal(isSourceFile('src/server.js'), true);
assert.equal(isSourceFile('src/components/App.jsx'), true);
assert.equal(isSourceFile('src/model.py'), true);
assert.equal(isSourceFile('README.md'), false);
assert.equal(isSourceFile('package.json'), false);
assert.equal(isSourceFile('node_modules/express/index.js'), false);
assert.equal(isSourceFile('dist/app.js'), false);

console.log('source-file filter tests passed');
